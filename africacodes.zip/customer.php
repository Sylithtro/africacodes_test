<?php
require_once "config.php";
Users::regCustomer();


?>